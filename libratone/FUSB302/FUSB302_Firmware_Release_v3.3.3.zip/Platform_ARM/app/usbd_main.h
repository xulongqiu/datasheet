
#ifndef _USBD_MAIN_H_
#define _USBD_MAIN_H_

void InitializeUSB( void );

#endif // _USBD_MAIN_H_
