

/*******************************************************************************
 * Function:        InitializeDelay
 * Input:           None
 * Return:          None
 * Description:     Set up a hardware timer used to implement a blocking delay.
 ******************************************************************************/
void InitializeDelay( void );
