#ifdef FSC_HAVE_DP

#ifndef __DISPLAY_PORT_CONFIGURE_H__
#define __DISPLAY_PORT_CONFIGURE_H__

#endif // __DISPLAY_PORT_CONFIGURE_H__

#endif // FSC_HAVE_DP

