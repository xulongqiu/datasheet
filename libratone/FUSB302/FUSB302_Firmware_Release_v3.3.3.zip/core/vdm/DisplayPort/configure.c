#ifdef FSC_HAVE_DP

#include "configure.h"

#endif // FSC_HAVE_DP
